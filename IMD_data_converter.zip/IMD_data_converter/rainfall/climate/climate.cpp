// ConsoleApplication5.cpp : Defines the entry point for the console application.
//
#define _CRT_SECURE_NO_DEPRECATE
#include "stdafx.h"


#include<stdio.h>

int    main(int argc,char *argv[])
        {
        float rf[69][65];
		int i,j ,k;
        FILE *fptr1,*fptr2;
		
        fptr1=fopen(argv[1],"rb");   // input file
        fptr2=fopen(argv[2],"w");

        if(fptr1==NULL)
        {
            printf("Can't open file 1");
            return 0;
        }
        if(fptr2==NULL)
        {
            printf("Can't open file 2");
            return 0;
        }

	k=1;
        while(fread(&rf,sizeof(rf),1,fptr1)==1)
        {
		fprintf(fptr2,"\nrecord = %d \n",k);
	        k++;
                for(i=0 ; i < 69 ; i++)
		{
        		fprintf(fptr2,"\n") ;
                	for(j=0 ; j < 65 ; j++)
				fprintf(fptr2," %6.1f",rf[i][j] );
                } 

        }
        fclose(fptr1);
        fclose(fptr2);

        return 0;

        } /* end of main */